docker-compose up --build -d
docker exec -it freepbx-arm64 bash
ps aux | grep asterisk